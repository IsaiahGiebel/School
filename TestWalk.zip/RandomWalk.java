package cisc230;

import java.util.Random;
public class RandomWalk {
	/*declaring the variables as private and int. xCord is the X-coordinate. yCord is the Y-coordinate.
	 * maxSteps is the maximum number of steps allowed. stepsTaken is the number of steps taken.
	 * boundary is the boundary. direction is used in the switch to choose direction of step.
	 * maxDistance is the maximum distance the object makes it from the origin.
	 */
	private int xCord,yCord,maxSteps,stepsTaken,boundary,direction,maxDistance;
	/*This constructor sets xCord,yCord,stepstTaken, and maxDistance to 0
	 * and takes two parameters used to assign maxSteps and boundary
	 */
	RandomWalk(int maxSteps1, int boundary1){
		xCord=0;
		yCord=0;
		stepsTaken=0;
		maxSteps=maxSteps1;
		boundary=boundary1;
		maxDistance=0;
	}
	/*This constructor sets maxDistance to 0 and has 4 parameters that assign values
	 * for maxSteps,boundary,xCord, and yCord
	 * this is constructor overloading
	 */
	RandomWalk (int maxSteps1, int boundary1, int startX, int startY){
		maxSteps=maxSteps1;
		boundary=boundary1;
		xCord=startX;
		yCord=startY;
		maxDistance=0;
	}
	
	//getter for the X coordinate
	public int getXCord(){
		return xCord;
	}
	//getter for the Y coordinate
	public int getYCord(){
		return yCord;
	}
	//getter for maxSteps
	public int getMaxSteps(){
		return maxSteps;
	}
	//getter for maxDistance
	public int getMaxDistance() {
		return maxDistance;
	}

	//to String method for printing stepsTaken and xCord and yCord
	public String toString() {
		return "Steps: " + stepsTaken + "; Position: " + "(" + xCord + "," + yCord + ")"; 
	}
	/* takeStep() is a method that uses random to generate a number 0-3
	 * which decides whether the xCord or yCord goes up or down 1
	 * the stepsTaken goes up by 1 each time
	 * maxDistance is assigned the maximum of the X coordinate and Y coordinate
	 * if this maximum is larger than maxDistance. Essentially updates maxDistance with each step 
	 */
	void takeStep() {
		Random rand=new Random();
		int direction=rand.nextInt(4);
		switch(direction) {
		case 0:
			xCord=xCord+1;
			break;
		case 1:
			xCord=xCord-1;
			break;
		case 2:
			yCord=yCord+1;
			break;
		case 3:
			yCord=yCord-1;
			break;
		}
		stepsTaken=stepsTaken+1;
		if(maxDistance<max(xCord,yCord)) {
			maxDistance=max(xCord,yCord);
		}
	}
	//returns true if less steps have been taken then maximum steps allowed and returns false otherwise
	boolean moreSteps() {
		if(stepsTaken<maxSteps) {
			return true;
		}
		else {
			return false;
		}
	}
	//returns true if the X and Y coordinates are within the boundary and returns false otherwise
	boolean inBounds() {
		if(Math.abs(xCord)<=boundary && Math.abs(yCord)<=boundary ) {
			return true;
		}
		else {
			return false;
		}
	}
	/*runs method takeStep() (makes the object take a step) while the object is in bounds
	 * and has not reached the maximum number of steps
	 */
	void walk() {
		while(moreSteps() && inBounds()) {
			takeStep();
		}
	}
	/*finds the largest absolute value between x and y and returns that absolute value
	 * is used in takeStep() method to find maxDistance (the maximum distance form the origin)
	 */
	private int max(int x,int y) {
		if(Math.abs(x)>=Math.abs(y)) {
			return Math.abs(x);
		}
		else {
			return Math.abs(y);
		}
	}
}

