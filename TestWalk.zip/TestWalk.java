package cisc230;

import java.util.Scanner;

public class TestWalk {
/*creating objects with obj2 using a scanner to input info from user for x,y,boundary,and maximum steps
 * obj1 and obj3 do not have x and y coordinates as parameters 
 * and those variables are set to 0 from the constructor
 */
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the boundary: ");
		int boundary=scan.nextInt();
		System.out.println("Enter the maximum number of steps: ");
		int maxSteps=scan.nextInt();
		System.out.println("Enter the initial X coordinate: ");
		int xCord=scan.nextInt();
		System.out.println("Enter the initial Y coordinate: ");
		int yCord=scan.nextInt();
		RandomWalk obj2=new RandomWalk(maxSteps,boundary,xCord,yCord);
		RandomWalk obj3=new RandomWalk(200,10);
		RandomWalk obj1=new RandomWalk(5,10);
		
		//obj1 uses a for loop to take 5 steps. The steps taken, max distance, and x and y coordinate are all printed
		System.out.println("obj1:");
		for(int i=1;i<=5;i++) {
			obj1.takeStep();
			System.out.println(obj1);
			System.out.println("The maximum distance reached is: " +obj1.getMaxDistance());
		}
		
		//obj2 uses a for loop to take 5 steps. The steps taken, max distance, and x and y coordinate are all printed
		System.out.println("");
		System.out.println("obj2:");
		for(int i=1;i<=5;i++) {
			obj2.takeStep();
			System.out.println(obj2);
			System.out.println("The maximum distance reached is: " +obj2.getMaxDistance());
		}
		
		//obj3 uses the walk method which uses a while loop(while object is is within boundary and less then max steps
		System.out.println("");
		System.out.println("obj3:");
		obj3.walk();
		System.out.println(obj3);
		
	}	
}
