package cisc230;

import java.util.Scanner;

public class DrunkenWalk {
/*the main method takes user input to assign the boundary, max steps, and number of drunks
 * it uses a for loop to simulate each drunk, calling a new object for each, and adding one to
 * the variable fell if the object in each loop goes farther than the boundary
 * it then prints out how many drunks fell out of total drunks simulated
 */
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the boundary: ");
		int boundary=scan.nextInt();
		System.out.println("Enter the maximum number of steps: ");
		int maxSteps=scan.nextInt();
		System.out.println("Enter the number of drunks: ");
		int drunks=scan.nextInt();
		int fell=0;
		for(int i=1;i<=drunks;i++) {
			RandomWalk obj1=new RandomWalk(maxSteps,boundary);
			obj1.walk();
				if( obj1.inBounds()==false) {
					fell=fell+1;
			}
		}
		System.out.println("There were "+fell+" out of "+drunks+" drunks that fell.");	
	}
}
