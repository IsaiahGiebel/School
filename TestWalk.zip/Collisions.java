package cisc230;

public class Collisions {
/* 2 objects are called with coordinates (-3,0) and (3,0)
 * the loop makes each object take a step while one of them has more steps to take. 
 * (in bounds does not matter since the boundary is much larger then the max steps allowed )
 * if they end up at the same position at the same time they have collided and 
 * collide adds one more to its value
 * this effectively counts then number of times two objects collide within a 2D space given 100,000 steps
 * the print statement prints off the number of times they collided
 */
	public static void main(String[] args) {
		int collide=0;
		RandomWalk obj1=new RandomWalk(100000,2000000,-3,0);
		RandomWalk obj2=new RandomWalk(100000,2000000,3,0);
		while(obj1.moreSteps() || obj2.moreSteps()) {
			obj1.takeStep();
			obj2.takeStep();
			if(samePosition(obj1,obj2)) {
				collide=collide+1;
			}
		}
		System.out.println("The particles collided "+collide+" times");
	}
	
	/*this method was created to make the main method less messy
	 * it returns true if both the X coordinate and the Y coordinate of 
	 * both of the objects are the same and returns false otherwise
	 * it checks if the objects are in the same position
	 */
	public static boolean samePosition(RandomWalk p1, RandomWalk p2) {
		if(p1.getXCord()==p2.getXCord() && p1.getYCord()==p2.getYCord()) {
			return true;
		}
		else {
			return false;
		}
	}
}


